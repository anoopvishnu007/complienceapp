import React, { Component } from 'react'
import {
  Divider,
  Icon,
  Image,
  Menu,
  Segment,
  Step,
  Container
} from 'semantic-ui-react'
import 'styling/semantic.less'

class LeftSidebar extends Component {
  render() {
    const nmLogo = '/images/nm.png'
    const cixLogo = '/images/cix.png'

    return (
    <Step.Group vertical>
        <Step active>
            <Icon name='envelope open outline' />
            <Step.Content>
            <Step.Title>Communication</Step.Title>
            </Step.Content>
        </Step>

        <Step>
            <Icon name='paperclip' />
            <Step.Content>
            <Step.Title>Complaints</Step.Title>
            </Step.Content>
        </Step>

        <Step>
            <Icon name='pen square' />
            <Step.Content>
            <Step.Title>Consortium</Step.Title>
            </Step.Content>
        </Step>
        <Step>
            <Icon name='file alternate' />
            <Step.Content>
            <Step.Title>Reports</Step.Title>
            </Step.Content>
        </Step>
    </Step.Group>
    )

    }
}
export default LeftSidebar