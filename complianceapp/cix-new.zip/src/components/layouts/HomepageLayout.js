import PropTypes from 'prop-types'
import React, { Component } from 'react'
import {
  Button,
  Container,
  Divider,
  Grid,
  Header,
  Icon,
  Step,
  Table,
  Image,
  List,
  Menu,
  Responsive,
  Segment,
  Sidebar,
  Visibility,
} from 'semantic-ui-react'
import 'styling/semantic.less'

import TopMenubar from '../TopMenubar'
import LeftSidebar from '../LeftSidebar'

class HomepageLayout extends Component {
  render() {
    const { children } = this.props
    return (
    <Responsive minWidth={Responsive.onlyTablet.minWidth}>
    <TopMenubar/>
    <Segment style={{ padding: '3em 0em' }} vertical>
      <Grid container stackable verticalAlign='middle'>
        <Grid.Row>
          <Grid.Column width={4}>
            <LeftSidebar />
          </Grid.Column>
          <Grid.Column floated='left' width={12}>
            {children}
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </Segment>
  </Responsive>
    )
  }
}

HomepageLayout.propTypes = {
  children: PropTypes.node,
}

export default HomepageLayout