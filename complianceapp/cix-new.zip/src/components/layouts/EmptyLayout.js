import PropTypes from 'prop-types'
import React, { Component } from 'react'
import {
  Container,
  Grid,
  Responsive,
  Segment
} from 'semantic-ui-react'
import 'styling/semantic.less'

import TopMenubar from '../TopMenubar'
import LeftSidebar from '../LeftSidebar'

class EmptyLayout extends Component {
  render() {
    const { children } = this.props
    return (
    //<Responsive minWidth={Responsive.onlyTablet.minWidth}>
    <Segment style={{ padding: '3em 0em' }} vertical>
      <Grid container stackable verticalAlign='middle'>
        <Grid.Row>
          <Grid.Column floated='left' width={16}>
            {children}
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </Segment>
  //</Responsive>
    )
  }
}

EmptyLayout.propTypes = {
  children: PropTypes.node,
}

export default EmptyLayout