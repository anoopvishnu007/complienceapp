import PropTypes from 'prop-types'
import React from 'react'
import { Icon,Table,Header,Image,Checkbox  } from 'semantic-ui-react'

import * as styles from './CommunicationList.less'

const CommunicationList = ({ children }) => (
    <Table basic='very' celled collapsing>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Action</Table.HeaderCell>
                <Table.HeaderCell>Content</Table.HeaderCell>
                <Table.HeaderCell>Flag Type</Table.HeaderCell>
                <Table.HeaderCell>Criticality</Table.HeaderCell>
              </Table.Row>
            </Table.Header>

            <Table.Body>
              <Table.Row>
                <Table.Cell>
                  <Checkbox toggle />
                </Table.Cell>
                <Table.Cell><p>Looks interesting, can we connect later today for the Annuities…</p></Table.Cell>
                <Table.Cell>Market Misconduct</Table.Cell>
                <Table.Cell><Icon name='stop' color='yellow' /></Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Checkbox toggle />
                </Table.Cell>
                <Table.Cell><p>Looks interesting, can we connect later today for the Annuities…</p></Table.Cell>
                <Table.Cell>Market Misconduct</Table.Cell>
                <Table.Cell><Icon name='stop' color='yellow' /></Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Checkbox toggle />
                </Table.Cell>
                <Table.Cell><p>Looks interesting, can we connect later today for the Annuities…</p></Table.Cell>
                <Table.Cell>Market Misconduct</Table.Cell>
                <Table.Cell><Icon name='stop' color='yellow' /></Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Checkbox toggle />
                </Table.Cell>
                <Table.Cell><p>Looks interesting, can we connect later today for the Annuities…</p></Table.Cell>
                <Table.Cell>Market Misconduct</Table.Cell>
                <Table.Cell><Icon name='stop' color='yellow' /></Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>
                  <Checkbox toggle />
                </Table.Cell>
                <Table.Cell><p>Looks interesting, can we connect later today for the Annuities…</p></Table.Cell>
                <Table.Cell>Market Misconduct</Table.Cell>
                <Table.Cell><Icon name='stop' color='yellow' /></Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
)

CommunicationList.propTypes = {
  children: PropTypes.node,
}

export default CommunicationList
