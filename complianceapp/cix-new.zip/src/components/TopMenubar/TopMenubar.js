import React, { Component } from 'react'
import {
  Divider,
  Icon,
  Image,
  Menu,
  Segment,
  Container
} from 'semantic-ui-react'
import 'styling/semantic.less'

class TopMenubar extends Component {
  render() {
    const nmLogo = '/images/nm.png'
    const cixLogo = '/images/cix.png'

    return (
    <Segment
        textAlign='center'
        style={{ padding: '1em 0em' }}
        vertical
        >
        <Menu
            pointing={true}
            secondary={false}
            size='large'
        >
            <Container>
            <Menu.Item >
            <Image src={nmLogo} size='medium' verticalAlign='middle' />
            </Menu.Item>
            <Menu.Item position='right'>
                <Image src={cixLogo} size='small' verticalAlign='middle' />
            </Menu.Item>
            </Container>
        </Menu>
    </Segment>
    )
  }
}

export default TopMenubar