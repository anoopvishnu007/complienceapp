import PropTypes from 'prop-types'
import React, { Component } from 'react'
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom';

import EmptyLayout from './components/layouts/EmptyLayout'
import HomepageLayout from './components/layouts/HomepageLayout'
import CommunicationList from './components/CommunicationList'
import Login from './components/Login'
// add router

const HomepageRoute = ({component: Component, ...rest}) => {
  return (
    <Route {...rest} render={matchProps => (
      localStorage.getItem('user') ? 
      <HomepageLayout>
          <Component {...matchProps} />
      </HomepageLayout>
      : 
      <Redirect to={{ pathname: '/signin', state: { from: matchProps.location } }} />
    )} />
  )
};


const PublicRoute = ({component: Component, ...rest}) => {
  return (
    <Route {...rest} render={matchProps => (
      <EmptyLayout>
          <Component {...matchProps} />
      </EmptyLayout>
    )} />
  )
};

const App = () => (
    <BrowserRouter>
      <Switch>
        {/*<BrowserRouter exact path="/">
            <Redirect to="/signin" />
        </BrowserRouter>*/}
        <HomepageRoute exact path="/" component={CommunicationList} />
        <PublicRoute path="/signin" component={Login} />
      </Switch>
    </BrowserRouter>
)


export default App